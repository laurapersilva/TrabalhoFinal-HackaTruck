//
//  Graficos.swift
//  ProjetoFinal
//
//  Created by Turma02-28 on 02/04/25.
//

import SwiftUI
import Charts

struct Graficos: View {
    
    @StateObject var model = ViewModel()
    
    var body: some View {
        NavigationStack {
            ZStack{
                Color("Principal").ignoresSafeArea()
                    VStack{
                        Image("logo")
                            .resizable()
                            .scaledToFit()
                            .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                            .frame(width: 90)
                        
                        ZStack{
                            Color(.white).ignoresSafeArea()
                            
                            VStack{
                                Spacer()
                          
                                    Chart {
                                        ForEach(model.gasto) { data in
                                            ForEach(data.spent, id: \.self) { s in
                                                BarMark(x: .value("Nomes", data.nome!) ,
                                                        y: .value("Gastos", s.gasto!) ).foregroundStyle(Color("Principal"))
                                            }
                                        }
                                    }
                                
                                .chartLegend(.hidden)
                                .frame(maxWidth: 300, maxHeight: 150)
                                
                                Spacer()
                                
                                
                                
                                Chart {
                                    ForEach(model.ganho) { d in
                                        
                                        BarMark(x: .value("Nomes", d.daattaa!) ,
                                                y: .value("Ganhos", d.ganho!) ).foregroundStyle(Color("Principal"))
                                        
                                        
                                    }
                                }
                                .chartLegend(.hidden)
                                .frame(maxWidth: 300, maxHeight: 150)
                               
                                Spacer()
                               
                                // Calcular o lucro diretamente na view
                                    let totalGastos = model.gasto.flatMap { $0.spent }.compactMap { $0.gasto }.reduce(0, +)
                                    let totalGanhos = model.ganho.compactMap { $0.ganho }.reduce(0, +)
                                    let lucro = totalGanhos - totalGastos
                                                    
                                    // Exibir o lucro calculado
                                    if lucro != 0 {
                                        Text("Lucro:").font(.title).foregroundStyle(Color("Principal"))
                                    Text(" R$ \(lucro, specifier: "%.2f")")
                                                            .font(.title)
                                                            .fontWeight(.bold)
                                                            .foregroundColor(lucro >= 0 ? .green : .red)
                                                            .padding()
                                    } else {
                                     Text(" Não disponível")
                                                            .font(.title)
                                                            .fontWeight(.bold)
                                                            .foregroundColor(.gray)
                                                            .padding()
                                    }
                            }
                        }.border(/*@START_MENU_TOKEN@*/Color.black/*@END_MENU_TOKEN@*/).cornerRadius(/*@START_MENU_TOKEN@*/3.0/*@END_MENU_TOKEN@*/).padding()
                            
       
                            
                        
                    }
            }
            .onAppear() {
                model.fetchGasto()
                model.fetchGanho()
                }
        }
    }
    
   
    
}


#Preview {
    Graficos()
}
