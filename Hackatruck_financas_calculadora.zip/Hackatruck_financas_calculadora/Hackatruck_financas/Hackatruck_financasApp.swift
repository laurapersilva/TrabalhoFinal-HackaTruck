//
//  Hackatruck_financasApp.swift
//  Hackatruck_financas
//
//  Created by Turma02-22 on 04/04/25.
//

import SwiftUI

@main
struct Hackatruck_financasApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
