//
//  Model.swift
//  Hackatruck_financas
//
//  Created by Turma02-22 on 04/04/25.
//

import Foundation

struct JurosBancos: Codable, Identifiable {
    // Create an ID from existing fields
    var id: String {
        return "\(InstituicaoFinanceira ?? "")-\(Modalidade ?? "")-\(InicioPeriodo ?? "")"
    }
    
    let InicioPeriodo: String?
    let FimPeriodo: String?
    let Segmento: String?
    let Modalidade: String?
    let InstituicaoFinanceira: String?
    let TaxaJurosAoMes: Double?
}
