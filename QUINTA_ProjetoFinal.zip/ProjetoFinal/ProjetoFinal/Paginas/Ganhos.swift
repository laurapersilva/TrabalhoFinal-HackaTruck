//
//  Gastos.swift
//  ProjetoFinal
//
//  Created by Turma02-28 on 02/04/25.
//

import SwiftUI

struct Ganhos: View {
    @State public var image = ["estado1", "estado2", "estado3"]
    @State public var irPraTela: Bool = false
    @State public var ganho: String = ""
    var body: some View {
        NavigationStack {
            ZStack{
                Color("Principal").ignoresSafeArea()
                VStack{
                    Image("logo")
                        .resizable()
                        .scaledToFit()
                        .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        .frame(width: 90)
                    
                    ZStack{
                        Color(.white)
                            .padding()
                            .cornerRadius(30)
                        
                        VStack{
                            Spacer()
                            VStack {
                                //substituir por navigation link pra registro_ganhos
                                NavigationLink(destination: RegistrarGanhoView(viewModel: ViewModel())) {
                                    HStack {
                                        Image(systemName: "plus.circle.fill")
                                            .font(.system(size: 20))
                                            .foregroundColor(.white)
                                        Text("Adicionar ganhos")
                                            .fontWeight(.semibold)
                                            .foregroundColor(.white)
                                    }
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 14)
                                    .background(
                                        RoundedRectangle(cornerRadius: 12)
                                            .fill(Color.green)
                                            .shadow(color: Color.black.opacity(0.1), radius: 3, x: 0, y: 2)
                                    )
                                    .padding(.horizontal)
                                    .padding(.bottom, 10)
                                }

                                NavigationLink(destination: ListaGanhosView()) {
                                    HStack {
                                        Image(systemName: "list.bullet.rectangle")
                                            .font(.system(size: 20))
                                            .foregroundColor(.white)
                                        Text("Listar ganhos")
                                            .fontWeight(.semibold)
                                            .foregroundColor(.white)
                                    }
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 14)
                                    .background(
                                        RoundedRectangle(cornerRadius: 12)
                                            .fill(Color.blue)
                                            .shadow(color: Color.black.opacity(0.1), radius: 3, x: 0, y: 2)
                                    )
                                    .padding(.horizontal)
                                }
                            }
                            Divider()
                                .frame(width: 300)
                            Spacer()
                            Image("Oncinha")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 250, height:250)
                            
                            Divider()
                                .frame(width: 300)
                            
                            VStack {
                                NavigationLink(destination: HistoriadoGato(viewModel: ViewModel())) {
                                    HStack {
                                        Image(systemName: "pawprint.fill")
                                            .font(.system(size: 20))
                                            .foregroundColor(.white)
                                        Text("História do Gato")
                                            .fontWeight(.semibold)
                                            .foregroundColor(.white)
                                    }
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 14)
                                    .background(
                                        RoundedRectangle(cornerRadius: 12)
                                            .fill(Color.purple)
                                            .shadow(color: Color.black.opacity(0.1), radius: 3, x: 0, y: 2)
                                    )
                                    .padding(.horizontal)
                                    .padding(.top, 10)
                                }
                                }
                               
                                
                                Text("PROPAGANDA")
                                    .frame(width: 300, height: 100)
                                    .background(Color(.gray))
                                    .padding(EdgeInsets(top: 0, leading: 50, bottom: 0, trailing: 50))
                                
                            }
                        }
                    }
                }
                
            }
        }
    }

#Preview {
    Ganhos()
}
