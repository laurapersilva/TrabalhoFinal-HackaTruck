//
//  Graficos.swift
//  ProjetoFinal
//
//  Created by Turma02-28 on 02/04/25.
//

import SwiftUI
import Charts


struct Graficos: View {
    
    @StateObject var model = ViewModel()
    
    var meses = ["Janeiro", "Fevereiro", "Marco", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"]
    @State private var mesSelecionado: String = "l"
    @State private var aux: String = "l"
    
    var body: some View {
        NavigationStack {
            ZStack{
                Color("Principal").ignoresSafeArea()
                VStack{
                    Image("logo")
                        .resizable()
                        .scaledToFit()
                        .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        .frame(width: 90)
                    
                    ZStack{
                        Color(.white).ignoresSafeArea()
                        
                        VStack{
                            Spacer()
                            
                            Chart {
                                ForEach(model.gasto) { data in
                                    BarMark(x: .value("Nomes", data.nome!) ,
                                                y: .value("Gastos", data.gasto!)
                                    ).foregroundStyle(Color("Principal"))
                                }
                            }
                            .chartLegend(.hidden)
                            .frame(maxWidth: 300, maxHeight: 150)
                            
                            Spacer()
                            
                            
                            
                            Chart {
                                ForEach(model.ganho) { d in
                                    BarMark(x: .value("Nomes", d.daattaa!) ,
                                            y: .value("Ganhos", d.ganho!)
                                    ).foregroundStyle(Color("Principal"))
                                }
                            }
                            .chartLegend(.hidden)
                            .frame(maxWidth: 300, maxHeight: 150)
                            
                            Spacer()
                            
                            Text("Saldo do mês de").font(.title).foregroundStyle(Color("Principal"))
                            VStack{
                                HStack {
                                    Picker("meses", selection: $mesSelecionado) {
                                        ForEach(meses, id: \.self) { mes in
                                            Text(mes)
                                        }
                                    }
                                    Button {
                                        aux = mesSelecionado
                                    } label: {
                                        Text("OK")
                                    }
                                }
                                
                            }
                            .frame(maxWidth: .infinity, alignment: .center)
                            
                            //lucro, specifier: "%.2f"
                            
                            Text(" R$ \(calcularMes(mes: aux), specifier: "%.2f")")
                                .font(.title)
                                .fontWeight(.bold)
                                .foregroundColor(.black)
                                .padding()
                        }
                    }.border(/*@START_MENU_TOKEN@*/Color.black/*@END_MENU_TOKEN@*/).cornerRadius(/*@START_MENU_TOKEN@*/3.0/*@END_MENU_TOKEN@*/).padding()
                }
            }
            .onAppear() {
                model.fetchGasto()
                model.fetchGanho()
            }
        }
    }
    
    func calcularMes(mes: String) ->  Float {
        var lucro: Float = 0.0
        var x: Float = 0.0
        var y: Float = 0.0
        
        if mes == "Janeiro" {
            //somatorio dos ganhos
            for d in model.ganho {
                let data = d.daattaa!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                
                if mesmes == 01 {
                    x = x + d.ganho!
                }
            }
            
            //somatorio dos gastos
            for d in model.gasto {
                let data = d.data!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                    
                if mesmes == 01 {
                    y = y + d.gasto!
                }
                
            }
            
            lucro = x - y
            
        }
        else if mes == "Fevereiro" {
            //somatorio dos ganhos
            for d in model.ganho {
                let data = d.daattaa!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                
                if mesmes == 02 {
                    x = x + d.ganho!
                }
            }
            
            //somatorio dos gastos
            for d in model.gasto {
                let data = d.data!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                    
                if mesmes == 02 {
                    y = y + d.gasto!
                }
                
            }
            
            lucro = x - y
        }
        else if mes == "Marco" {
            //somatorio dos ganhos
            for d in model.ganho {
                let data = d.daattaa!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                
                if mesmes == 03 {
                    x = x + d.ganho!
                }
            }
            
            //somatorio dos gastos
            for d in model.gasto {
                let data = d.data!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                    
                if mesmes == 03 {
                    y = y + d.gasto!
                }
                
            }
            
            lucro = x - y
        }
        else if mes == "Abril" {
            //somatorio dos ganhos
            for d in model.ganho {
                let data = d.daattaa!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                
                if mesmes == 04 {
                    x = x + d.ganho!
                }
            }
            
            for d in model.gasto {
                let data = d.data!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                    
                if mesmes == 04 {
                    y = y + d.gasto!
                }
                
            }
            
            lucro = x - y
        }
        
        else if mes == "Maio" {
            //somatorio dos ganhos
            for d in model.ganho {
                let data = d.daattaa!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                
                if mesmes == 05 {
                    x = x + d.ganho!
                }
            }
            
            for d in model.gasto {
                let data = d.data!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                    
                if mesmes == 05 {
                    y = y + d.gasto!
                }
                
            }
            
            lucro = x - y
        }
        else if mes == "Junho" {
            //somatorio dos ganhos
            for d in model.ganho {
                let data = d.daattaa!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                
                if mesmes == 06 {
                    x = x + d.ganho!
                }
            }
            
            for d in model.gasto {
                let data = d.data!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                    
                if mesmes == 06 {
                    y = y + d.gasto!
                }
                
            }
            
            lucro = x - y
        }
        else if mes == "Julho" {
            //somatorio dos ganhos
            for d in model.ganho {
                let data = d.daattaa!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                
                if mesmes == 07 {
                    x = x + d.ganho!
                }
            }
            
            for d in model.gasto {
                let data = d.data!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                    
                if mesmes == 07 {
                    y = y + d.gasto!
                }
                
            }
            
            lucro = x - y
        }
        else if mes == "Agosto" {
            //somatorio dos ganhos
            for d in model.ganho {
                let data = d.daattaa!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                
                if mesmes == 08 {
                    x = x + d.ganho!
                }
            }
            
            for d in model.gasto {
                let data = d.data!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                    
                if mesmes == 08 {
                    y = y + d.gasto!
                }
                
            }
            
            lucro = x - y
        }
        else if mes == "Setembro" {
            //somatorio dos ganhos
            for d in model.ganho {
                let data = d.daattaa!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                
                if mesmes == 09 {
                    x = x + d.ganho!
                }
            }
            
            for d in model.gasto {
                let data = d.data!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                    
                if mesmes == 09 {
                    y = y + d.gasto!
                }
                
            }
            
            lucro = x - y
        }
        else if mes == "Outubro"{
            //somatorio dos ganhos
            for d in model.ganho {
                let data = d.daattaa!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                
                if mesmes == 10 {
                    x = x + d.ganho!
                }
            }
            
            for d in model.gasto {
                let data = d.data!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                    
                if mesmes == 10 {
                    y = y + d.gasto!
                }
                
            }
            
            lucro = x - y
        }
        else if mes == "Novembro" {
            //somatorio dos ganhos
            for d in model.ganho {
                let data = d.daattaa!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                
                if mesmes == 11 {
                    x = x + d.ganho!
                }
            }
            
            for d in model.gasto {
                let data = d.data!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                    
                if mesmes == 11 {
                    y = y + d.gasto!
                }
                
            }
            
            lucro = x - y
        }
        else if mes == "Dezembro" {
            //somatorio dos ganhos
            for d in model.ganho {
                let data = d.daattaa!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                
                if mesmes == 12 {
                    x = x + d.ganho!
                }
            }
            
            for d in model.gasto {
                let data = d.data!
                let components = data.components(separatedBy: "/")
                let mesmes = Int(components[1])
                    
                if mesmes == 12 {
                    y = y + d.gasto!
                }
                
            }
            
            lucro = x - y
        }
        return lucro
    }
}



#Preview {
    Graficos()
}



