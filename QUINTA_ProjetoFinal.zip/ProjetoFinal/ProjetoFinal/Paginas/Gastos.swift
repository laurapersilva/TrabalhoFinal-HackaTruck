import SwiftUI

struct Gastos: View {
    @StateObject var viewModel = ViewModel()
    @State private var sheet: Bool = false
    @State var categoria: String = ""
    @State var isCategoriaVisible:Bool = false
    @State var isGastoVisible:Bool = false
    
    @State var id:Int = 1
    @State var idRef: Int = 0
    @State var nome:String = ""
    @State var gasto:Float = 0.0
    @State var data:String = ""
    
    @State var idAux: Int = 0
    
    @State var categSelecid: String = ""
    @State var categSelecidRef:Int = 0
    
    @State var someTextInView: Int = 0
    
    var body: some View {
        NavigationStack {
            ZStack{
                Color("Principal").ignoresSafeArea()
                VStack{
                    Image("logo")
                        .resizable()
                        .scaledToFit()
                        .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        .frame(width: 90)
                    
                    ZStack{
                        Color(.white)
                            .padding()
                            .cornerRadius(30)
                        
                        VStack{
                            Button(action: { sheet = true }) {
                                Text("Adicionar gasto")
                                    .font(.title2)
                                    .frame(width: 190, height: 80)
                                    .foregroundColor(.white)
                                    .background(Color("Principal"))
                                    .cornerRadius(10)
                                    .padding(EdgeInsets(top: 40, leading: 50, bottom: 0, trailing: 50))
                            }
                            .sheet(isPresented: $sheet) {
                                print("Sheet dismissed!")
                            } content: {
                                AddGastoView()
                            }
                            
                            Spacer()
                            ScrollView(){
                                VStack{
                                    ForEach(viewModel.Gastos
                                            , id: \._id){i in
                                        HStack{
                                            if i.nome != "" {
                                                VStack{
                                                    HStack {
                                                        Text(i.nome!)
                                                            .onTapGesture {
                                                                print("\(i.gasto!)")
                                                            }
                                                        Button(action: {
                                                            withAnimation {
                                                                isGastoVisible.toggle()
                                                                categSelecid = i._id!
                                                            }
                                                        }) {
                                                            Image(systemName: "plus")
                                                                .scaledToFit()
                                                                .foregroundColor(.black)
                                                                .padding()
                                                        }
                                                    }
                                                    
                                                    //                                                        Text(i.data! + " " + "\(i.gasto!)")
                                                    
                                                }
                                            }
                                            
                                            if isGastoVisible && categSelecid == i._id{
                                                VStack{
                                                    TextField("Adicione o gasto", value: $gasto, format: .number)
                                                        .textFieldStyle(RoundedBorderTextFieldStyle())
                                                        .padding()
                                                    TextField("Adicione a data", text: $data)
                                                        .textFieldStyle(RoundedBorderTextFieldStyle())
                                                        .padding()
                                                }
                                                Button {
                                                    if gasto > 0 && !data.isEmpty {
                                                        viewModel.postCategoriaBruno(categoria: Categoria(id: 0, idRef: categSelecidRef, nome: "", gasto: gasto, data: data))
                                                        print("button ok")
                                                        // Limpar os campos após adicionar o gasto
                                                        gasto = 0
                                                        data = ""
                                                        isGastoVisible = false
                                                    }
                                                    viewModel.fetchGastoBruno()
                                                } label: {
                                                    Text("Post data")
                                                        .padding()
                                                        .background(Color.blue)
                                                        .foregroundColor(.white)
                                                        .cornerRadius(8)
                                                }
                                            }
                                        }
                                        
                                    }
                                }
                            } .padding(EdgeInsets(top: 30, leading: 10, bottom: 40, trailing: 40))
                        }
                    }
                }
                .onAppear() {
                    
                    Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
                        someTextInView += 1
                        viewModel.fetchGastoBruno()
                    }
                }
            }
            
        }
    }
    
    struct AddGastoView: View {
        @Environment(\.dismiss) private var dismiss
        
        @StateObject var viewModel = ViewModel()
        @State var categoria: String = ""
        @State var isCategoriaVisible:Bool = false
        @State var isGastoVisible:Bool = false
        
        @State var id:Int = 1
        @State var idRef: Int = 0
        @State var nome:String = ""
        @State var gasto:Float = 0.0
        @State var data:String = ""
        
        @State var idAux: Int = 0
        
        @State var categSelecid: String = ""
        @State var categSelecidRef:Int = 0
        
        
        var body: some View {
            VStack() {
                Text("Adicione um novo gasto")
                    .font(.system(size: 25))
                    .scaledToFit()
                TextField(text: $categoria, prompt: Text("Nome do gasto")) {
                    Text("Title")
                }
                
                HStack {
                    Button("Cancelar") {
                        // Cancel saving and dismiss.
                        dismiss()
                    }.foregroundStyle(Color(.red))
                    
                    Spacer()
                    Button("Confirmo") {
                        func ordID() -> Int{
                            if viewModel.Gastos.first != nil {
                                for i in Array(arrayLiteral: viewModel.Gastos.sorted(by: {$0.id > $1.id}).first!) {
                                    idAux = i.id+1
                                }
                            }
                            return idAux
                        }
                        
                        if !categoria.isEmpty {
                            viewModel.postCategoriaBruno(categoria: Categoria(_id: nil, _rev: nil, id:ordID(), idRef: 0, nome: categoria, gasto: 0, data: ""))
                            categoria = ""
                            
                        }
                        viewModel.fetchGastoBruno()
                        dismiss()
                    }.foregroundStyle(Color("Principal"))
                }
            }
            .padding(20)
            .frame(width: 300, height: 200)
        }
    }
}

#Preview {
    Gastos()
}
