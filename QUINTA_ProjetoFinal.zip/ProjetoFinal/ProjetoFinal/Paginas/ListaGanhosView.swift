import SwiftUI

struct ListaGanhosView: View {
    @StateObject var viewModel = ViewModel()
    @State private var isLoading = true
    @State private var showRegistrarGanho = false
    
    private func carregarGanhos() {
        isLoading = true
        viewModel.fetchGanho()
        
        // Delay curto para garantir que a UI atualize
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
            isLoading = false
        }
    }
        
    var body: some View {
        ZStack {
            Color("Principal").ignoresSafeArea()
            
            VStack(spacing: 16) {
                Text("Lista de Ganhos")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding(.top, 10)
                    .colorInvert()
                
                Button(action: carregarGanhos) {
                    Text("Atualizar")
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.horizontal, 24)
                        .padding(.vertical, 12)
                        .background(Color.blue)
                        .cornerRadius(12)
                        .shadow(color: .black.opacity(0.1), radius: 3, x: 0, y: 2)
                }
                .padding(.bottom, 6)
                
                // Mantendo o mesmo ForEach
                ForEach(viewModel.ganho) { ganho in
                    // View para cada item com estilo melhorado
                    HStack {
                        VStack(alignment: .leading, spacing: 6) {
                            Text(ganho.daattaa ?? "Sem data")
                                .font(.headline)
                                .foregroundStyle(.black)
                            
                            if let descricao = ganho.descricao, !descricao.isEmpty {
                                Text(descricao)
                                    .font(.subheadline)
                                    .foregroundStyle(.gray)
                            }
                        }
                        
                        Spacer()
                        
                        Text("R$ \(String(format: "%.2f", ganho.ganho ?? 0))")
                            .fontWeight(.bold)
                            .foregroundStyle(.green)
                    }
                    .padding(16)
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .fill(Color(.systemGray6))
                            .shadow(color: .black.opacity(0.05), radius: 2, x: 0, y: 1)
                    )
                    .padding(.horizontal)
                    .scaledToFit()
                }
                
                Spacer()
            }
            .padding(.vertical)
            .onAppear {
                viewModel.fetchGanho()
            }
        }
    }
}

#Preview {
    ListaGanhosView()
}
