//
//  Model.swift
//  Hackatruck_financas
//
//  Created by Turma02-22 on 04/04/25.
//

import Foundation

//
//  ViewModel.swift
//  DesafioHacka_07
//
//  Created by Turma02-22 on 26/03/25.
//

import Foundation

class ViewModel : ObservableObject{
    @Published var bancos : [JurosBancos] = []
    
    func fetch() {
        guard let url = URL(string: "https://olinda.bcb.gov.br/olinda/servico/taxaJuros/versao/v2/odata/TaxasJurosDiariaPorInicioPeriodo?$top=100&$filter=Modalidade%20eq%20'Cart%C3%A3o%20de%20cr%C3%A9dito%20-%20parcelado%20-%20Pr%C3%A9-fixado'&$orderby=InicioPeriodo%20desc&$format=json&$select=InicioPeriodo,FimPeriodo,Segmento,Modalidade,InstituicaoFinanceira,TaxaJurosAoMes") else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            guard let data = data, error == nil else {
                return
            }
            do {
                // Define a structure to match the API response
                struct APIResponse: Decodable {
                    let value: [JurosBancos]
                }
                
                let apiResponse = try JSONDecoder().decode(APIResponse.self, from: data)
                
                DispatchQueue.main.async {
                    self?.bancos = apiResponse.value
                }
            } catch {
                print("Decoding error:", error)
            }
        }
        task.resume()
    }
    
}
