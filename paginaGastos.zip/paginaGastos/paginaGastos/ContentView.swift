//
//  ContentView.swift
//  paginaGastos
//
//  Created by Turma02-4 on 03/04/25.
//

import SwiftUI


struct ContentView: View {
    @StateObject var viewModel = ViewModel()
    var body: some View {
        ZStack{
            Color.green.edgesIgnoringSafeArea(.all)
            VStack {
                Image(systemName: "globe")
                    .imageScale(.large)
                    .foregroundStyle(.tint)
                    .padding()
                HStack(){
                    Text("Adicionar Gasto")
                    Image(systemName: "plus")
                }
                ForEach(viewModel.Gastos){e in
                    Text(e.nome!)
                    ForEach(e.spent, id: \.self){i in
                        Text("\(i.gasto!)")
                    }
                }
                Spacer()
            }
        }
        .onAppear(){
            viewModel.fetch()
        }
    }
}

#Preview {
    ContentView()
}
