//
//  paginaGastosApp.swift
//  paginaGastos
//
//  Created by Turma02-4 on 03/04/25.
//

import SwiftUI

@main
struct paginaGastosApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
