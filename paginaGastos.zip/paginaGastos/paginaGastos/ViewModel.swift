//
//  ViewModel.swift
//  paginaGastos
//
//  Created by Turma02-4 on 03/04/25.
//

import Foundation
class ViewModel: ObservableObject {
    @Published var Gastos: [titulo] = []
    
    func fetch(){
        guard let url = URL(string:
            "http://127.0.0.1:1880/getGastosBr") else{
                return
                }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error
            in
                guard let data = data, error == nil else{
                    return
                }
            do{
                let parsed = try JSONDecoder().decode([titulo].self, from: data)
                DispatchQueue.main.async{
                    self?.Gastos = parsed
                }
            } catch {
                print(error)
            }
        }
        task.resume()
    }
}
