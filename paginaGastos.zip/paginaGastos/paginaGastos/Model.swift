//
//  Model.swift
//  paginaGastos
//
//  Created by Turma02-4 on 03/04/25.
//

import Foundation

struct titulo: Decodable, Identifiable{
    var id:Int
    var nome: String?
    var spent: [gastos]
}
struct gastos: Decodable, Hashable{
    var gasto: Float?
    var data: String?
}
