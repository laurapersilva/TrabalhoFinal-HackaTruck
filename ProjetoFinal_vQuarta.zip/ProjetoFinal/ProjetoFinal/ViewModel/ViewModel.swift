//
//  ViewModel.swift
//  ProjetoFinal
//
//  Created by Turma02-28 on 03/04/25.
//

import Foundation
import Charts

class ViewModel: ObservableObject {
    
    @Published var gasto: [Gasto] = []
    @Published var ganho: [Ganho] = []
    @Published var bancos : [JurosBancos] = []
    
    
    //atualizar essa funcao de fetch ganho para  acompanhar a registrarganho
    func fetchBanco() {
        guard let url = URL(string: "https://olinda.bcb.gov.br/olinda/servico/taxaJuros/versao/v2/odata/TaxasJurosDiariaPorInicioPeriodo?$top=100&$filter=Modalidade%20eq%20'Cart%C3%A3o%20de%20cr%C3%A9dito%20-%20parcelado%20-%20Pr%C3%A9-fixado'&$orderby=InicioPeriodo%20desc&$format=json&$select=InicioPeriodo,FimPeriodo,Segmento,Modalidade,InstituicaoFinanceira,TaxaJurosAoMes") else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            guard let data = data, error == nil else {
                return
            }
            do {
                // Define a structure to match the API response
                struct APIResponse: Decodable {
                    let value: [JurosBancos]
                }
                
                let apiResponse = try JSONDecoder().decode(APIResponse.self, from: data)
                
                DispatchQueue.main.async {
                    self?.bancos = apiResponse.value
                }
            } catch {
                print("Decoding error:", error)
            }
        }
        task.resume()
    }
  
    
    //Funcao para gastos
    func fetchGasto() {
        //pega a url da json
        guard let url = URL(string: "http://127.0.0.1:1880/getGasto") else {
            return
        }
            
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error
            in
            guard let data = data, error == nil else {
                return
            }
            
            do { //tentar decodificar
                let parsed = try JSONDecoder().decode([Gasto].self, from: data)
                
                //para ordernar esse processo
                DispatchQueue.main.async {
                    self?.gasto = parsed
                }
            } catch {
                print(error)
            }
        }
        task.resume()
    }
    
    //funcao para ganhos
    func fetchGanho() {
        //pega a url da json
        guard let url = URL(string: "http://127.0.0.1:1880/getGanho") else {
            return
        }
            
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error
            in
            guard let data = data, error == nil else {
                return
            }
            
            do { //tentar decodificar
                let parsed = try JSONDecoder().decode([Ganho].self, from: data)
                
                //para ordernar esse processo
                DispatchQueue.main.async {
                    self?.ganho = parsed
                }
            } catch {
                print(error)
            }
        }
        task.resume()
    }
   
    func registrarGanho(valor: Float, data: String, completion: @escaping (Bool) -> Void) {
        guard let url = URL(string: "http://127.0.0.1:1880/postGanho") else {
            completion(false)
            return
        }
        
        // Criar um objeto com os campos necessários
        let dados: [String: Any] = [
            "ganho": valor,
            "daattaa": data
        ]
        
        do {
            // Serializar para JSON
            let jsonData = try JSONSerialization.data(withJSONObject: dados, options: [])
            
            // Log para debug
            if let jsonString = String(data: jsonData, encoding: .utf8) {
                print("JSON enviado: \(jsonString)")
            }
            
            // Configurar requisição
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = jsonData
            
            let task = URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
                let sucesso = error == nil && (response as? HTTPURLResponse)?.statusCode ?? 0 >= 200 && (response as? HTTPURLResponse)?.statusCode ?? 0 < 300
                
                DispatchQueue.main.async {
                    if sucesso {
                        self?.fetchGanho()
                    }
                    completion(sucesso)
                }
            }
            
            task.resume()
        } catch {
            print("Erro ao serializar JSON: \(error)")
            completion(false)
        }
    }}
