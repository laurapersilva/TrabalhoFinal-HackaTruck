//
//  ProjetoFinalApp.swift
//  ProjetoFinal
//
//  Created by Turma02-28 on 02/04/25.
//

import SwiftUI

@main
struct ProjetoFinalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
