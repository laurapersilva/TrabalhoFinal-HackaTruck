//
//  GanhoCardView.swift
//  ProjetoFinal
//
//  Created by Turma02-22 on 09/04/25.
//

import Foundation
import SwiftUI

// Card para exibir um ganho
struct GanhoCardView: View {
    let ganho: Ganho
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.white.opacity(0.1))
            
            HStack {
                // Ícone
                ZStack {
                    Circle()
                        .fill(Color.green.opacity(0.2))
                        .frame(width: 50, height: 50)
                    
                    Image(systemName: "arrow.up.circle.fill")
                        .resizable()
                        .frame(width: 25, height: 25)
                        .foregroundStyle(.green)
                }
                
                // Informações do ganho
                VStack(alignment: .leading, spacing: 4) {
                    Text(ganho.daattaa ?? "Sem data")
                        .font(.subheadline)
                        .foregroundStyle(.white.opacity(0.7))
                    
                    // Se tiver descrição no seu modelo, descomente esta parte
                    // Text(ganho.descricao ?? "")
                    //     .font(.caption)
                    //     .foregroundStyle(.white.opacity(0.6))
                }
                .padding(.leading, 5)
                
                Spacer()
                
                // Valor
                Text("R$ \(String(format: "%.2f", ganho.ganho ?? 0))")
                    .font(.headline)
                    .foregroundStyle(.green)
            }
            .padding()
        }
    }
}

#Preview {
    // Cria um exemplo de ganho para o preview
    let exemploGanho = Ganho(
        id: 1,
        ganho: 1500.50,
        daattaa: "09/04/2025"
    )
    
    return GanhoCardView(ganho: exemploGanho)
        .preferredColorScheme(.dark) // Para ver melhor o card com fundo escuro
        .padding()
}
