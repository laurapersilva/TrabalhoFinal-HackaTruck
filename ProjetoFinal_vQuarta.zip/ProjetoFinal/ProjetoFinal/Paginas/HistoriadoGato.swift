import SwiftUI
import GoogleGenerativeAI

struct HistoriadoGato: View {
    
    let model = GenerativeModel(name: "gemini-1.5-flash", apiKey: APIKey.default)
    @ObservedObject var viewModel: ViewModel // Referência ao seu ViewModel existente
    
    @State var textInput = ""
    @State var aiResponse = ""
    @State var isLoading = false
    
    var body: some View {
        NavigationStack {
            ZStack{
                Color("Principal").ignoresSafeArea()
                VStack{
                    Image("logo")
                        .resizable()
                        .scaledToFit()
                        .clipShape(Circle())
                        .frame(width: 100)
                    Text("Terapia Financeira")
                        .foregroundStyle(.white)
                        .font(.largeTitle)
                    
                    Text("Converse seus problemas financeiros com a nossa inteligência artificial")
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.white)
                        .font(.subheadline)
                        .padding(0.25)
                    
                    Spacer()
                    
                    ScrollView {
                        if isLoading {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                .scaleEffect(1.5)
                                .padding(50)
                        } else {
                            Text(aiResponse)
                                .multilineTextAlignment(.center)
                                .foregroundStyle(.white)
                                .font(.headline)
                                .padding(EdgeInsets(top: 50, leading: 50, bottom: 0, trailing: 50))
                        }
                    }
                    
                    HStack {
                        TextField("Enter a message", text: $textInput)
                            .textFieldStyle(.roundedBorder)
                            .foregroundStyle(.black)
                        Button {
                            sendMessage()
                        } label: {
                            Image(systemName: "paperplane.fill")
                        }
                        .disabled(isLoading)
                    }.padding()
                }
            }
        }
    }
    
    func sendMessage() {
        aiResponse = ""
        isLoading = true
        
        Task {
            do {
                // Crie um JSON com os dados financeiros para enviar ao Gemini
                let dadosFinanceirosJSON = criarJSONDadosFinanceiros()
                
                let prompt = """
                Sempre me envie assuntos relacionados a finanças, tendo em mente os seguintes dados financeiros do usuário:
                
                DADOS FINANCEIROS:
                \(dadosFinanceirosJSON)
                
                PERGUNTA DO USUÁRIO:
                \(textInput)
                
                Por favor, analise os dados financeiros fornecidos e ofereça conselhos personalizados baseados na situação financeira real do usuário. Considere o equilíbrio entre gastos e ganhos, os históricos de transações, e forneça insights sobre juros bancários quando relevante.
                """
                
                let response = try await model.generateContent(prompt)
                
                guard let text = response.text else {
                    aiResponse = "Desculpe, não consegui processar isso."
                    isLoading = false
                    return
                }
                
                textInput = ""
                aiResponse = text
                isLoading = false
                
            } catch {
                aiResponse = "Algo deu errado!\n\(error.localizedDescription)"
                isLoading = false
            }
        }
    }
    
    func criarJSONDadosFinanceiros() -> String {
        // Calcular o total de gastos
        let totalGastos = calcularTotalGastos()
        
        // Calcular o total de ganhos
        let totalGanhos = calcularTotalGanhos()
        
        // Formatar gastos por categoria
        let gastosFormatados = formatarGastos()
        
        // Formatar ganhos recentes
        let ganhosFormatados = formatarGanhos()
        
        // Formatar juros de bancos
        let jurosFormatados = formatarJurosBancos()
        
        // Montar o JSON completo
        return """
        {
          "totalGastos": \(totalGastos),
          "totalGanhos": \(totalGanhos),
          "saldoAtual": \(totalGanhos - totalGastos),
          "gastosPorCategoria": {
            \(gastosFormatados)
          },
          "ganhosRecentes": [
            \(ganhosFormatados)
          ],
          "jurosDisponíveis": [
            \(jurosFormatados)
          ]
        }
        """
    }
    
    func calcularTotalGastos() -> Float {
        // Somar todos os gastos de todas as categorias
        var total: Float = 0
        
        for gasto in viewModel.gasto {
            for spent in gasto.spent {
                if let valor = spent.gasto {
                    total += valor
                }
            }
        }
        
        return total
    }
    
    func calcularTotalGanhos() -> Float {
        // Somar todos os ganhos
        var total: Float = 0
        
        for ganho in viewModel.ganho {
            if let valor = ganho.ganho {
                total += valor
            }
        }
        
        return total
    }
    
    func formatarGastos() -> String {
        // Agrupar gastos por categoria (nome)
        var gastosPorCategoria: [String: Float] = [:]
        
        for gasto in viewModel.gasto {
            let nomeCategoria = gasto.nome ?? "Sem categoria"
            var totalCategoria: Float = 0
            
            for spent in gasto.spent {
                if let valor = spent.gasto {
                    totalCategoria += valor
                }
            }
            
            gastosPorCategoria[nomeCategoria] = totalCategoria
        }
        
        // Converter para formato JSON
        return gastosPorCategoria.map { (categoria, valor) -> String in
            return """
              "\(categoria)": \(valor)
            """
        }.joined(separator: ",\n")
    }
    
    func formatarGanhos() -> String {
        // Formatar ganhos em formato JSON
        return viewModel.ganho.map { ganho -> String in
            let valor = ganho.ganho ?? 0
            let data = ganho.daattaa ?? "Sem data"
            
            return """
            {
              "id": \(ganho.id),
              "valor": \(valor),
              "data": "\(data)"
            }
            """
        }.joined(separator: ",\n")
    }
    
    func formatarJurosBancos() -> String {
        // Formatar informações de juros bancários em formato JSON
        return viewModel.bancos.map { juros -> String in
            let instituicao = juros.InstituicaoFinanceira ?? "Desconhecido"
            let modalidade = juros.Modalidade ?? "Desconhecido"
            let taxaMensal = juros.TaxaJurosAoMes ?? 0.0
            
            return """
            {
              "instituicao": "\(instituicao)",
              "modalidade": "\(modalidade)",
              "taxaJurosMensal": \(taxaMensal),
              "periodo": "\(juros.InicioPeriodo ?? "") a \(juros.FimPeriodo ?? "")"
            }
            """
        }.joined(separator: ",\n")
    }
}

#Preview {
    HistoriadoGato(viewModel: ViewModel()) // Use seu ViewModel real aqui
}
