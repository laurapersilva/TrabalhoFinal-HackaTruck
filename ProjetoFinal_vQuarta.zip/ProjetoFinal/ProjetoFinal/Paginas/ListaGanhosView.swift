import SwiftUI

struct ListaGanhosView: View {
    @StateObject var viewModel = ViewModel()
    @State private var isLoading = true
    @State private var showRegistrarGanho = false
    @State private var mesFiltrado: Int? = nil
    
    
    var body: some View {
        NavigationStack {
            ZStack {
                // Fundo
                Color("Principal").ignoresSafeArea()
                
                VStack {
                    // Header
                    Image("logo")
                        .resizable()
                        .scaledToFit()
                        .clipShape(Circle())
                        .frame(width: 90)
                    
                    Text("Ganhos")
                        .foregroundStyle(.white)
                        .font(.largeTitle)
                    
                    // Filtro por mês
                    HStack {
                        Text("Filtrar por mês:")
                            .foregroundStyle(.white)
                        
                        Picker("Mês", selection: $mesFiltrado) {
                            Text("Todos").tag(nil as Int?)
                            Text("Janeiro").tag(1 as Int?)
                            Text("Fevereiro").tag(2 as Int?)
                            Text("Março").tag(3 as Int?)
                            Text("Abril").tag(4 as Int?)
                            Text("Maio").tag(5 as Int?)
                            Text("Junho").tag(6 as Int?)
                            Text("Julho").tag(7 as Int?)
                            Text("Agosto").tag(8 as Int?)
                            Text("Setembro").tag(9 as Int?)
                            Text("Outubro").tag(10 as Int?)
                            Text("Novembro").tag(11 as Int?)
                            Text("Dezembro").tag(12 as Int?)
                        }
                        .pickerStyle(.menu)
                        .background(Color.white.opacity(0.2))
                        .cornerRadius(8)
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 10)
                    
                    // Total de ganhos
                    ZStack {
                        RoundedRectangle(cornerRadius: 15)
                            .fill(Color.white.opacity(0.1))
                        
                        VStack {
                            Text("Total de Ganhos")
                                .foregroundStyle(.white)
                                .font(.headline)
                            
                            Text("R$ \(String(format: "%.2f", calcularTotalGanhosFiltrados()))")
                                .foregroundStyle(.white)
                                .font(.title)
                                .fontWeight(.bold)
                        }
                        .padding()
                    }
                    .frame(height: 80)
                    .padding(.horizontal)
                    
                    // Lista de ganhos
                    if isLoading {
                        Spacer()
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            .scaleEffect(1.5)
                        Spacer()
                    } else if ganhosFiltrados.isEmpty {
                        Spacer()
                        Text("Nenhum ganho registrado")
                            .foregroundStyle(.white)
                            .font(.headline)
                        Spacer()
                    } else {
                        ScrollView {
                            LazyVStack(spacing: 12) {
                                ForEach(ganhosFiltrados) { ganho in
                                    GanhoCardView(ganho: ganho)
                                }
                            }
                            .padding(.horizontal)
                        }
                    }
                    
                    Spacer()
                    
                    // Botão para adicionar novo ganho
                    Button(action: {
                        showRegistrarGanho = true
                    }) {
                        HStack {
                            Image(systemName: "plus.circle.fill")
                            Text("Novo Ganho")
                        }
                        .foregroundStyle(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.green)
                        .cornerRadius(10)
                        .padding(.horizontal)
                    }
                }
                .padding(.vertical)
            }
            .navigationBarTitleDisplayMode(.inline)
            .onAppear {
                carregarGanhos()
            }
            .sheet(isPresented: $showRegistrarGanho, onDismiss: {
                carregarGanhos()
            }) {
                RegistrarGanhoView(viewModel: viewModel)
            }
        }
    }
    
    // Função para carregar os ganhos
    private func carregarGanhos() {
        isLoading = true
        viewModel.fetchGanho()
        
        // Simular um pequeno delay para mostrar o loading
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            isLoading = false
        }
    }
    
    // Calcular total de ganhos filtrados
    private func calcularTotalGanhosFiltrados() -> Float {
        return ganhosFiltrados.reduce(0) { total, ganho in
            total + (ganho.ganho ?? 0)
        }
    }
    
    // Filtrar ganhos por mês
    private var ganhosFiltrados: [Ganho] {
        guard let mesFiltrado = mesFiltrado else {
            return viewModel.ganho.sorted {
                (ganho1, ganho2) -> Bool in
                guard let data1 = ganho1.daattaa, let data2 = ganho2.daattaa else {
                    return false
                }
                return data1 > data2 // Ordenar do mais recente para o mais antigo
            }
        }
        
        return viewModel.ganho.filter { ganho in
            guard let dataString = ganho.daattaa else { return false }
            let components = dataString.components(separatedBy: "/")
            guard components.count >= 2, let mesGanho = Int(components[1]) else {
                return false
            }
            
            return mesGanho == mesFiltrado
        }.sorted {
            (ganho1, ganho2) -> Bool in
            guard let data1 = ganho1.daattaa, let data2 = ganho2.daattaa else {
                return false
            }
            return data1 > data2
        }
    }
    
}
    
    #Preview {
        ListaGanhosView()
    }

