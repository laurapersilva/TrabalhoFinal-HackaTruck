import SwiftUI

struct RegistrarGanhoView: View {
    @ObservedObject var viewModel: ViewModel
    @Environment(\.dismiss) var dismiss
    
    @State private var valor: String = ""
    @State private var descricao: String = ""
    @State private var dataGanho = Date()
    @State private var isLoading = false
    @State private var showAlert = false
    @State private var alertMessage = ""
    
    private var valorFloat: Float? {
        return Float(valor.replacingOccurrences(of: ",", with: "."))
    }
    
    private var dataFormatada: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd" // Formato usado no banco de dados
        return formatter.string(from: dataGanho)
    }
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color("Principal").ignoresSafeArea()
                
                VStack {
                    Image("logo")
                        .resizable()
                        .scaledToFit()
                        .clipShape(Circle())
                        .frame(width: 90)
                    
                    Text("Registrar Ganho")
                        .foregroundStyle(.white)
                        .font(.largeTitle)
                        .padding(.bottom, 20)
                    
                    // Card Principal
                    VStack(spacing: 20) {
                        TextField("Valor (R$)", text: $valor)
                            .keyboardType(.decimalPad)
                            .padding()
                            .background(RoundedRectangle(cornerRadius: 10).fill(Color.white))
                            .foregroundColor(.black)
                        
                        TextField("Descrição (opcional)", text: $descricao)
                            .padding()
                            .background(RoundedRectangle(cornerRadius: 10).fill(Color.white))
                            .foregroundColor(.black)
                        
                        // Seletor de Data
                        DatePicker(
                            "Data",
                            selection: $dataGanho,
                            displayedComponents: .date
                        )
                        .datePickerStyle(.compact)
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 10).fill(Color.white))
                        .foregroundColor(.black)
                        
                        // Botão de Registrar
                        Button(action: {
                            registrarNovoGanho()
                        }) {
                            HStack {
                                if isLoading {
                                    ProgressView()
                                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                } else {
                                    Text("Registrar Ganho")
                                        .fontWeight(.bold)
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(valorFloat != nil ? Color.green : Color.gray.opacity(0.5))
                            .foregroundColor(.white)
                            .cornerRadius(10)
                        }
                        .disabled(valorFloat == nil || isLoading)
                    }
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 15).fill(Color.white.opacity(0.1)))
                    .padding(.horizontal)
                    
                    Spacer()
                }
                .padding()
            }
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarItems(trailing: Button("Cancelar") {
                dismiss()
            }.foregroundColor(.white))
            .alert(alertMessage, isPresented: $showAlert) {
                Button("OK") {
                    if alertMessage.contains("sucesso") {
                        dismiss()
                    }
                }
            }
        }
    }
    
    func registrarNovoGanho() {
        guard let valorGanho = valorFloat else {
            alertMessage = "Por favor, insira um valor válido"
            showAlert = true
            return
        }
        
        isLoading = true
        
        viewModel.registrarGanho(
            valor: valorGanho,
            data: dataFormatada
        ) { sucesso in
            isLoading = false
            
            if sucesso {
                alertMessage = "Ganho registrado com sucesso!"
            } else {
                alertMessage = "Erro ao registrar ganho. Tente novamente."
            }
            
            showAlert = true
        }
    }
}

// Preview
#Preview {
    RegistrarGanhoView(viewModel: ViewModel())
}
